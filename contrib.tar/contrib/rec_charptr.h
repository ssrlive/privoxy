#ifndef REC_CHARPTR_H_INCLUDED
#define REC_CHARPTR_H_INCLUDED
#define REC_CHARPTR_H_VERSION "$Id: rec_charptr.h,v 1.1 2001/07/29 18:50:04 rodney.stromlund Exp $"
/*********************************************************************
 *
 * File        :  $Source: /cvsroot/ijbswa/current/rec_char.h,v $
 *
 * Purpose     :  A "derived class" of gen_list_rec.
 *
 * Copyright   :  Written by and Copyright (C) 2001 the SourceForge
 *                IJBSWA team.  http://ijbswa.sourceforge.net
 *
 *                This program is free software; you can redistribute it
 *                and/or modify it under the terms of the GNU General
 *                Public License as published by the Free Software
 *                Foundation; either version 2 of the License, or (at
 *                your option) any later version.
 *
 *                This program is distributed in the hope that it will
 *                be useful, but WITHOUT ANY WARRANTY; without even the
 *                implied warranty of MERCHANTABILITY or FITNESS FOR A
 *                PARTICULAR PURPOSE.  See the GNU General Public
 *                License for more details.
 *
 *                The GNU General Public License should be included with
 *                this file.  If not, you can view it at
 *                http://www.gnu.org/copyleft/gpl.html
 *                or write to the Free Software Foundation, Inc., 59
 *                Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * VI users		:	Please "set tabstop=3 shiftwidth=3" to view this file,
 *						and edit IJB, correctly.
 *
 * Revisions   :
 *    $Log: rec_charptr.h,v $
 *
 *********************************************************************/


#ifdef __cplusplus
extern "C" {
#endif


struct derived_rec_charptr
{
	/* private: */
	struct gen_list_rec parent_rec;
	char *contents;
};

/* public: */
extern struct derived_rec_charptr *	derived_rec_charptr_construct( const char *_contents );
extern struct derived_rec_charptr *	derived_rec_charptr_copy_construct( const struct derived_rec_charptr *this_rec );
extern struct derived_rec_charptr *	derived_rec_charptr_destruct( struct derived_rec_charptr *this_rec );
extern const struct derived_rec_charptr *derived_rec_charptr_stream( const struct derived_rec_charptr *this_rec );
extern int									derived_rec_charptr_equal( const struct derived_rec_charptr *this_rec, const struct derived_rec_charptr *eq_rec );

/* struct/class COMPLETE */


#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* ndef REC_CHARPTR_H_INCLUDED */

/*
  Local Variables:
  tab-width: 3
  end:
*/
