#ifndef GEN_LIST_H_INCLUDED
#define GEN_LIST_H_INCLUDED
#define GEN_LIST_H_VERSION "$Id: gen_list.h,v 1.1 2001/07/29 18:50:04 rodney.stromlund Exp $"
/*********************************************************************
 *
 * File        :  $Source: /cvsroot/ijbswa/current/gen_list.h,v $
 *
 * Purpose     :  To create some functions to do generic doubly linked
 *						list management.
 *
 * Copyright   :  Written by and Copyright (C) 2001 the SourceForge
 *                IJBSWA team.  http://ijbswa.sourceforge.net
 *
 *                This program is free software; you can redistribute it
 *                and/or modify it under the terms of the GNU General
 *                Public License as published by the Free Software
 *                Foundation; either version 2 of the License, or (at
 *                your option) any later version.
 *
 *                This program is distributed in the hope that it will
 *                be useful, but WITHOUT ANY WARRANTY; without even the
 *                implied warranty of MERCHANTABILITY or FITNESS FOR A
 *                PARTICULAR PURPOSE.  See the GNU General Public
 *                License for more details.
 *
 *                The GNU General Public License should be included with
 *                this file.  If not, you can view it at
 *                http://www.gnu.org/copyleft/gpl.html
 *                or write to the Free Software Foundation, Inc., 59
 *                Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * VI users		:	Please "set tabstop=3 shiftwidth=3" to view this file,
 *						and edit IJB, correctly.
 *
 * Revisions   :
 *    $Log: gen_list.h,v $
 *
 *********************************************************************/


#ifdef __cplusplus
extern "C" {
#endif

#include "isa.h"


extern int list_is_quiet;

#define LIST_SHOW(stmt)  if ( ! list_is_quiet ) { stmt; }


struct gen_list_rec;
typedef struct gen_list_rec *			(*rec_copy_construct)( struct gen_list_rec *copy_rec );
typedef struct gen_list_rec *			(*rec_destruct)( struct gen_list_rec *this_rec );
typedef const struct gen_list_rec *	(*rec_stream)( const struct gen_list_rec *this_rec );
typedef int									(*rec_equal)( const struct gen_list_rec *this_rec, const struct gen_list_rec *eq_rec );
typedef struct gen_list_rec *			(*rec_iterate)( struct gen_list_rec *this_rec );

typedef void * (*rec_method)( void *this_rec, ... );


enum VT_ENTRIES
{
	VT_REC_COPY_CONSTRUCT,
	VT_REC_DESTRUCT,
	VT_REC_STREAM,
	VT_REC_EQUAL,
	VT_REC_MAX
};


typedef const rec_method *t_vtable;


struct gen_list_rec
{
	/* private: */
	t_vtable vtable;
	enum GEN_LIST_ISA isa;
	int sizeof_rec;
	/* contents HERE */
};
/* public: */
extern struct gen_list_rec *			gen_list_rec_construct( enum GEN_LIST_ISA isa, int sizeof_rec, const t_vtable _vtable );
extern struct gen_list_rec *			gen_list_rec_copy_construct( const struct gen_list_rec *this_rec );
extern struct gen_list_rec *			gen_list_rec_destruct( struct gen_list_rec *this_rec );
extern const struct gen_list_rec *	gen_list_rec_stream( const struct gen_list_rec *this_rec );
extern int									gen_list_rec_equal( const struct gen_list_rec *this_rec, const struct gen_list_rec *eq_rec );

/* struct/class COMPLETE */


/**********************************************************************/

/* private: to gen_list */
struct gen_list_node;


struct gen_list
{
	/* private: */
	struct gen_list_node *first;
	struct gen_list_node *last;
};
/* gen_list_insert_node */

/* public: */
extern struct gen_list *				gen_list_construct();
extern struct gen_list *				gen_list_copy_construct( const struct gen_list *this_list );
extern struct gen_list *				gen_list_destruct( struct gen_list *this_list );
extern struct gen_list *				gen_list_remove_all( struct gen_list *this_list );
extern struct gen_list_rec *			gen_list_remove( struct gen_list *this_list, struct gen_list_rec *_rec );
extern struct gen_list_rec *			gen_list_get_first( const struct gen_list *this_list );
extern struct gen_list_rec *			gen_list_get_last( const struct gen_list *this_list );
extern const struct gen_list_node *	gen_list_insert( struct gen_list *this_list, struct gen_list_rec *_rec );
extern const struct gen_list *		gen_list_stream( const struct gen_list *this_list );
extern int									gen_list_equal( const struct gen_list *this_list, const struct gen_list *eq_list );
extern struct gen_list_rec *			gen_list_find( const struct gen_list *this_list, struct gen_list_rec *rec );
extern struct gen_list_rec *			gen_list_iterate( struct gen_list *this_list, rec_iterate iter );
/* struct/class COMPLETE */


#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* ndef GEN_LIST_H_INCLUDED */

/*
  Local Variables:
  tab-width: 3
  end:
*/
