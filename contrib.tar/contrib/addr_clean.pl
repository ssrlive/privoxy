#!/usr/bin/perl

##	*********************************************************************
##	*
##	* File			:	$Source: addr_clean.pl,v $
##	*
##	* Purpose		:	Cleans addresses out of ./test_list and replaces
##	*						them with "english" replacements.
##	*
##	* Usage			:	./test_list | ./addr_clean.pl
##	*
##	* Copyright		:	This program is free software; you can redistribute it 
##	*						and/or modify it under the terms of the GNU General
##	*						Public License as published by the Free Software
##	*						Foundation; either version 2 of the License, or (at
##	*						your option) any later version.
##	*
##	*						This program is distributed in the hope that it will
##	*						be useful, but WITHOUT ANY WARRANTY; without even the
##	*						implied warranty of MERCHANTABILITY or FITNESS FOR A
##	*						PARTICULAR PURPOSE.	See the GNU General Public
##	*						License for more details.
##	*
##	*						The GNU General Public License should be included with
##	*						this file.	If not, you can view it at
##	*						http://www.gnu.org/copyleft/gpl.html
##	*						or write to the Free Software Foundation, Inc., 59
##	*						Temple Place - Suite 330, Boston, MA  02111-1307, USA.
##	*
##	**********************************************************************/

use strict;


my $nMaxList = 0;
my $nMaxNode = 0;
my $nMaxRec = 0;
my %aaTranslation;
my $strLine;

while ( $strLine = <STDIN> )
{
	if ( $strLine =~ m!(list.*=\s*)(0x[0-9a-f]+)! )
	{
		my $str1 = $1;
		my $str2 = $2;

		if ( ! defined $aaTranslation{$str2} )
		{
			$aaTranslation{$str2} = "list" . ++ $nMaxList;
		}
		$strLine =~ s!(list.*=\s*)(0x[0-9a-f]+)!$str1($aaTranslation{$str2})!;
	}


	if ( $strLine =~ m!(node.*=\s*)(0x[0-9a-f]+)! )
	{
		my $str1 = $1;
		my $str2 = $2;

		if ( ! defined $aaTranslation{$str2} )
		{
			$aaTranslation{$str2} = "node" . ++ $nMaxNode;
		}
		$strLine =~ s!(node.*=\s*)(0x[0-9a-f]+)!$str1($aaTranslation{$str2})!;
	}


	if ( $strLine =~ m!(rec.*=\s*(iter_. \.\.\. )?)(0x[0-9a-f]+)! )
	{
		my $str1 = $1;
		my $str2 = $3;

		if ( ! defined $aaTranslation{$str2} )
		{
			$aaTranslation{$str2} = "rec" . ++ $nMaxRec;
		}
		$strLine =~ s!(rec.*=\s*(iter_. \.\.\. )?)(0x[0-9a-f]+)!$str1($aaTranslation{$str2})!;
	}


	## Catch the copy constuct syntax

	if ( $strLine =~ m!(list.*=>\s*)(0x[0-9a-f]+)! )
	{
		my $str1 = $1;
		my $str2 = $2;

		if ( ! defined $aaTranslation{$str2} )
		{
			$aaTranslation{$str2} = "list" . ++ $nMaxList;
		}
		$strLine =~ s!(list.*=>\s*)(0x[0-9a-f]+)!$str1($aaTranslation{$str2})!;
	}


	if ( $strLine =~ m!(node.*=>\s*)(0x[0-9a-f]+)! )
	{
		my $str1 = $1;
		my $str2 = $2;

		if ( ! defined $aaTranslation{$str2} )
		{
			$aaTranslation{$str2} = "node" . ++ $nMaxNode;
		}
		$strLine =~ s!(node.*=>\s*)(0x[0-9a-f]+)!$str1($aaTranslation{$str2})!;
	}


	if ( $strLine =~ m!(rec.*=>\s*)(0x[0-9a-f]+)! )
	{
		my $str1 = $1;
		my $str2 = $2;

		if ( ! defined $aaTranslation{$str2} )
		{
			$aaTranslation{$str2} = "rec" . ++ $nMaxRec;
		}
		$strLine =~ s!(rec.*=>\s*)(0x[0-9a-f]+)!$str1($aaTranslation{$str2})!;
	}

	print( $strLine );

}
