const char isa_rcs[] = "$Id: isa.c,v 1.1 2001/11/30 21:55:51 rodney Exp $";
/*********************************************************************
 *
 * File        :  $Source: /home/rodney/devl/ijb_beta/contrib/isa.c,v $
 *
 * Purpose     :  Pronounced "is a".  To create "english" translations
 *						for all linked "classes".
 *
 *						NOTE:	this header file must appear once and only once
 *								per project.
 *
 * Copyright   :  Written by and Copyright (C) 2001 the SourceForge
 *                IJBSWA team.  http://ijbswa.sourceforge.net
 *
 *                This program is free software; you can redistribute it
 *                and/or modify it under the terms of the GNU General
 *                Public License as published by the Free Software
 *                Foundation; either version 2 of the License, or (at
 *                your option) any later version.
 *
 *                This program is distributed in the hope that it will
 *                be useful, but WITHOUT ANY WARRANTY; without even the
 *                implied warranty of MERCHANTABILITY or FITNESS FOR A
 *                PARTICULAR PURPOSE.  See the GNU General Public
 *                License for more details.
 *
 *                The GNU General Public License should be included with
 *                this file.  If not, you can view it at
 *                http://www.gnu.org/copyleft/gpl.html
 *                or write to the Free Software Foundation, Inc., 59
 *                Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * VI users		:	Please "set tabstop=3 shiftwidth=3" to view this file,
 *						and edit IJB, correctly.
 *
 * Revisions   :
 *    $Log: isa.c,v $
 *    Revision 1.1  2001/11/30 21:55:51  rodney
 *    Initial revision
 *
 *
 *********************************************************************/


#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gen_list.h"
#include "isa.h"

const char isa_h_rcs[] = ISA_H_VERSION;


/* Pronounce "ra" phonectically and you get "array", which this variable is. */
char *isa_ra[] =
{
	"GEN_LIST_REC",
	"REC_MALLOC_POLICE",
	"REC_CHAR",
	"REC_CHARPTR",
	"REC_DOUBLE",
	"REC_LONG",
	NULL
};
