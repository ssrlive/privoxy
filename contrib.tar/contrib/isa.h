#ifndef ISA_H_INCLUDED
#define ISA_H_INCLUDED
#define ISA_H_VERSION "$Id: isa.h,v 1.1 2001/07/29 18:50:04 rodney.stromlund Exp $"
/*********************************************************************
 *
 * File        :  $Source: /cvsroot/ijbswa/current/isa.h,v $
 *
 * Purpose     :  Pronounced "is a".  To create "english" translations
 *						for all linked "classes".
 *
 *						NOTE:	this header file must appear once and only once
 *								per project.
 *
 * Copyright   :  Written by and Copyright (C) 2001 the SourceForge
 *                IJBSWA team.  http://ijbswa.sourceforge.net
 *
 *                This program is free software; you can redistribute it
 *                and/or modify it under the terms of the GNU General
 *                Public License as published by the Free Software
 *                Foundation; either version 2 of the License, or (at
 *                your option) any later version.
 *
 *                This program is distributed in the hope that it will
 *                be useful, but WITHOUT ANY WARRANTY; without even the
 *                implied warranty of MERCHANTABILITY or FITNESS FOR A
 *                PARTICULAR PURPOSE.  See the GNU General Public
 *                License for more details.
 *
 *                The GNU General Public License should be included with
 *                this file.  If not, you can view it at
 *                http://www.gnu.org/copyleft/gpl.html
 *                or write to the Free Software Foundation, Inc., 59
 *                Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * VI users		:	Please "set tabstop=3 shiftwidth=3" to view this file,
 *						and edit IJB, correctly.
 *
 * Revisions   :
 *    $Log: isa.h,v $
 *
 *********************************************************************/


#ifdef __cplusplus
extern "C" {
#endif


enum GEN_LIST_ISA
{
	ISA_GEN_LIST_REC,
	ISA_MALLOC_POLICE,
	ISA_CHAR,
	ISA_CHARPTR,
	ISA_DOUBLE,
	ISA_LONG,
	ISA_MAX
};


/* Pronounce "ra" phonectically and you get "array", which this variable is. */
extern char *isa_ra[];


#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* ndef ISA_H_INCLUDED */

/*
  Local Variables:
  tab-width: 3
  end:
*/
