const char main_rcs[] = "$Id: main.c,v 1.1 2001/10/25 03:40:48 rodney.stromlund Exp $";
/*********************************************************************
 *
 * File        :  $Source: /cvsroot/ijbswa/current/gen_list.c,v $
 *
 * Purpose     :  To test "generic list" creation and manipulation.
 *
 * Copyright   :  Written by and Copyright (C) 2001 the SourceForge
 *                IJBSWA team.  http://ijbswa.sourceforge.net
 *
 *                This program is free software; you can redistribute it
 *                and/or modify it under the terms of the GNU General
 *                Public License as published by the Free Software
 *                Foundation; either version 2 of the License, or (at
 *                your option) any later version.
 *
 *                This program is distributed in the hope that it will
 *                be useful, but WITHOUT ANY WARRANTY; without even the
 *                implied warranty of MERCHANTABILITY or FITNESS FOR A
 *                PARTICULAR PURPOSE.  See the GNU General Public
 *                License for more details.
 *
 *                The GNU General Public License should be included with
 *                this file.  If not, you can view it at
 *                http://www.gnu.org/copyleft/gpl.html
 *                or write to the Free Software Foundation, Inc., 59
 *                Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * VI users		:	Please "set tabstop=3 shiftwidth=3" to view this file,
 *						and edit IJB, correctly.
 *
 * Note			:	This output assumes (per IJB standards) that tabs are
 *						set to 3 characters.  If you run this in a terminal,
 *						you may want to run this as so:
 *							>./test_list 2>&1 | expand -t3 | ./addr_clean.pl
 *						This will expand the tab to 3 columns and then replace
 *						"0x" style addresses with more human readable ones.
 *
 * Revisions   :
 *    $Log: main.c,v $
 *
 *********************************************************************/


#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gen_list.h"
#include "rec_char.h"
#include "rec_charptr.h"
#include "rec_double.h"
#include "rec_long.h"
#include "malloc_police.h"


extern const char isa_rcs[];
extern const char isa_h_rcs[];
extern const char gen_list_rcs[];
extern const char gen_list_h_rcs[];
extern const char malloc_police_rcs[];
extern const char malloc_police_h_rcs[];
extern const char rec_charptr_rcs[];
extern const char rec_charptr_h_rcs[];
extern const char rec_long_rcs[];
extern const char rec_long_h_rcs[];
extern const char rec_double_rcs[];
extern const char rec_double_h_rcs[];
extern const char rec_char_rcs[];
extern const char rec_char_h_rcs[];
extern const char rec_malloc_police_rcs[];
extern const char rec_malloc_police_h_rcs[];
extern const char main_rcs[];


/*********************************************************************
 *
 * Function    :  my_custom_charptr_iterator_1
 *
 * Description :  This funtion is called once for every record in a
 *						list.  Or at least until we return non-NULL.  BTW,
 *						this function always returns NULL, thus it will
 *						iterate over the entire list.
 *
 * Parameters  :
 *          1  :  The record.
 *
 * Returns     :  NULL
 *
 *********************************************************************/
struct derived_rec_charptr *my_custom_charptr_iterator_1( struct derived_rec_charptr *this_rec )
{
	printf( "\
\t\tcharptr iterator_1 this_rec\t\t\t\t= iter_1 ... %p
\t\tcharptr iterator_1 this_rec->contents\t= iter_1 ... %s\n\n", (const void *)this_rec, this_rec->contents );
	return( NULL );

}


/*********************************************************************
 *
 * Function    :  my_custom_charptr_iterator_2
 *
 * Description :  This funtion is called once for every record in a
 *						list.  Or at least until we return non-NULL.  BTW,
 *						this function always returns non-NULL, thus it will
 *						iterate over only 1 record.
 *
 * Parameters  :
 *          1  :  The record.
 *
 * Returns     :  The record.
 *
 *********************************************************************/
struct derived_rec_charptr *my_custom_charptr_iterator_2( struct derived_rec_charptr *this_rec )
{
	printf( "\
\t\tcharptr iterator_1 this_rec\t\t\t\t= iter_2 ... %p
\t\tcharptr iterator_1 this_rec->contents\t= iter_2 ... %s\n\n", (const void *)this_rec, this_rec->contents );
	return( this_rec );

}


/*********************************************************************
 *
 * Function    :  main
 *
 * Description :  Test the doubly linked list as it is so far.
 *
 * Parameters  :  None
 *
 * Returns     :  N/A
 *
 *********************************************************************/
int main( int argc, const char **argv )
{
	struct gen_list *lcharptr;
	struct gen_list *llong;
	struct gen_list *ldouble;
	struct gen_list *lchar;

	struct gen_list *lcharptr_c;
	struct gen_list *llong_c;
	struct gen_list *ldouble_c;
	struct gen_list *lchar_c;

	struct gen_list_rec *f_rec;

	struct gen_list *no_own_list;
	struct gen_list_rec *no_own_rec1;
	struct gen_list_rec *no_own_rec2;
	struct gen_list_rec *no_own_rec3;

	printf( "\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n\n",
			  gen_list_rcs,
			  gen_list_h_rcs,
			  isa_rcs,
			  isa_h_rcs,
			  malloc_police_rcs,
			  malloc_police_h_rcs,
			  rec_char_rcs,
			  rec_char_h_rcs,
			  rec_charptr_rcs,
			  rec_charptr_h_rcs,
			  rec_long_rcs,
			  rec_long_h_rcs,
			  rec_double_rcs,
			  rec_double_h_rcs,
			  rec_malloc_police_rcs,
			  rec_malloc_police_h_rcs,
			  main_rcs );


	/* Force a memory leak to test the strdup/malloc/free police. */
	/* NOTE: this should trigger the alphanum check of allocated memory. */
	strcpy( MALLOC( 60 ), "Force a memory leak to test the strdup/malloc/free police." );


	printf( "** -- Calling gen_list_construct to constuct a charptr list -- **\n" );
	lcharptr = gen_list_construct();

	gen_list_insert( lcharptr, (struct gen_list_rec *)derived_rec_charptr_construct( "Rodney Stromlund" ) );
	gen_list_insert( lcharptr, f_rec = (struct gen_list_rec *)derived_rec_charptr_construct( "RJS" ) );
	gen_list_insert( lcharptr, (struct gen_list_rec *)derived_rec_charptr_construct( "jammin!" ) );

	printf( "** -- Calling gen_list_stream to test streaming a charptr list -- **\n" );
	gen_list_stream( lcharptr );

	printf( "** -- Calling gen_list_find to find the 2nd charptr record -- **\n" );
	f_rec = gen_list_find( lcharptr, f_rec );
	printf( "Found rec = %p\n", f_rec );
	derived_rec_charptr_stream( (const struct derived_rec_charptr *)f_rec );


	printf( "** -- Calling gen_list_copy_construct to test copy construct the charptr list -- **\n" );
	lcharptr_c = gen_list_copy_construct( lcharptr );

	printf( "** -- Calling gen_list_equal to see if the copied list is the same as the orig -- **
** -- NOTE: they will NOT be because the charptr copy constructor changes the string contents -- **\n" );
	printf( "Are these 2 equal? => %d\n\n", gen_list_equal( lcharptr, lcharptr_c ) );

	printf( "** -- Calling gen_list_stream to stream a copied charptr list -- **\n" );
	gen_list_stream( lcharptr_c );


	printf( "** -- Calling gen_list_construct to constuct a long list -- **\n" );
	llong = gen_list_construct();


	gen_list_insert( llong, no_own_rec1 = (struct gen_list_rec *)derived_rec_long_construct( 1 ) );
	gen_list_insert( llong, no_own_rec2 = (struct gen_list_rec *)derived_rec_long_construct( 100 ) );
	gen_list_insert( llong, no_own_rec3 = (struct gen_list_rec *)derived_rec_long_construct( 200 ) );

	printf( "** -- Calling gen_list_stream to test streaming a long list -- **\n" );
	gen_list_stream( llong );


	printf( "** -- Calling gen_list_copy_construct to test copy construct the long list -- **\n" );
	llong_c = gen_list_copy_construct( llong );

	printf( "** -- Calling gen_list_stream to stream a copied long list -- **\n" );
	gen_list_stream( llong_c );

	printf( "** -- Calling gen_list_construct to test a no-owner long list -- **\n" );
	no_own_list = gen_list_construct();
	gen_list_insert( no_own_list, no_own_rec1 );
	gen_list_insert( no_own_list, no_own_rec2 );
	gen_list_insert( no_own_list, no_own_rec3 );

	printf( "** -- Calling gen_list_stream to stream a no-owner list -- **\n" );
	gen_list_stream( no_own_list );

	printf( "** -- Calling gen_list_equal to see if list and no-owner list are equal  NOTE: they should be. -- **\n" );
	printf( "Are these 2 equal? => %d\n\n", gen_list_equal( llong, no_own_list ) );


	printf( "** -- Calling gen_list_construct to constuct a double list -- **\n" );
	ldouble = gen_list_construct();

	gen_list_insert( ldouble, (struct gen_list_rec *)derived_rec_double_construct( 3.0 ) );
	gen_list_insert( ldouble, (struct gen_list_rec *)derived_rec_double_construct( 3.1 ) );
	gen_list_insert( ldouble, (struct gen_list_rec *)derived_rec_double_construct( 3.14 ) );

	printf( "** -- Calling gen_list_stream to test streaming a double list -- **\n" );
	gen_list_stream( ldouble );


	printf( "** -- Calling gen_list_copy_construct to test copy construct the double list -- **\n" );
	ldouble_c = gen_list_copy_construct( ldouble );

	printf( "** -- Calling gen_list_stream to stream a copied double list -- **\n" );
	gen_list_stream( ldouble_c );


	printf( "** -- Calling gen_list_construct to constuct a char list -- **\n" );
	lchar = gen_list_construct();

	gen_list_insert( lchar, (struct gen_list_rec *)derived_rec_char_construct( '1' ) );
	gen_list_insert( lchar, (struct gen_list_rec *)derived_rec_char_construct( 'A' ) );
	gen_list_insert( lchar, (struct gen_list_rec *)derived_rec_char_construct( 'a' ) );

	printf( "** -- Calling gen_list_stream to test streaming a char list -- **\n" );
	gen_list_stream( lchar );


	printf( "** -- Calling gen_list_copy_construct to test copy construct the char list -- **\n" );
	lchar_c = gen_list_copy_construct( lchar );

	printf( "** -- Calling gen_list_equal to see if the copied list is the same as the orig  NOTE: they should be. -- **\n" );
	printf( "Are these 2 equal? => %d\n\n", gen_list_equal( lchar, lchar_c ) );

	printf( "** -- Calling gen_list_stream to stream a copied char list -- **\n" );
	gen_list_stream( lchar_c );


	printf( "** -- Calling gen_list_iterate to iterate a charptr list -- **
** -- NOTE: this iterator (my_custom_charptr_iterator_1) will iterate the whole list. -- **\n" );
	gen_list_iterate( lcharptr,	(rec_iterate)my_custom_charptr_iterator_1 );

	printf( "** -- Calling gen_list_iterate to iterate a copied charptr list -- **
** -- NOTE: this iterator (my_custom_charptr_iterator_2) will return after the first iteration. -- **\n" );
	gen_list_iterate( lcharptr_c,	(rec_iterate)my_custom_charptr_iterator_2 );


	printf( "** -- Calling gen_list_iterate_reverse to iterate a charptr list -- **
** -- NOTE: this iterator (my_custom_charptr_iterator_1) will iterate the whole list. -- **\n" );
	gen_list_iterate_reverse( lcharptr,	(rec_iterate)my_custom_charptr_iterator_1 );

	printf( "** -- Calling gen_list_iterate_reverse to iterate a copied charptr list -- **
** -- NOTE: this iterator (my_custom_charptr_iterator_2) will return after the first iteration. -- **\n" );
	gen_list_iterate_reverse( lcharptr_c,	(rec_iterate)my_custom_charptr_iterator_2 );


	printf( "** -- Calling gen_list_equal to see if 2 different typed lists are equal  NOTE: they should not be. -- **\n" );
	printf( "Are these 2 equal? => %d\n\n", gen_list_equal( lcharptr, llong ) );


	printf( "** -- Calling gen_list_remove_all to erase a no-owner list -- **\n" );
	no_own_list = gen_list_remove_all( no_own_list );

	printf( "** -- Calling gen_list_destruct to destruct a no-owner list -- **\n" );
	no_own_list = gen_list_destruct( no_own_list );


	printf( "** -- Calling gen_list_remove to remove the first record of a copied charptr list -- **\n" );
	derived_rec_charptr_destruct( (struct derived_rec_charptr *)gen_list_remove( lcharptr_c, gen_list_get_first( lcharptr_c ) ) );

	printf( "** -- Calling gen_list_remove to remove the last record of a copied long list -- **\n" );
	derived_rec_long_destruct( (struct derived_rec_long *)gen_list_remove( llong_c, gen_list_get_last( llong_c ) ) );

	printf( "** -- Calling gen_list_remove to remove the middle record of an original charptr list -- **\n" );
	derived_rec_charptr_destruct( (struct derived_rec_charptr *)gen_list_remove( lcharptr, f_rec ) );

	printf( "** -- Calling gen_list_remove to remove the all 3 records of a copied char list (first to last) -- **\n" );
	derived_rec_char_destruct( (struct derived_rec_char *)gen_list_remove( lchar_c, gen_list_get_first( lchar_c ) ) );
	derived_rec_char_destruct( (struct derived_rec_char *)gen_list_remove( lchar_c, gen_list_get_first( lchar_c ) ) );
	derived_rec_char_destruct( (struct derived_rec_char *)gen_list_remove( lchar_c, gen_list_get_first( lchar_c ) ) );

	printf( "** -- Calling gen_list_remove to remove the all 3 records of the original char list (last to first) -- **\n" );
	derived_rec_char_destruct( (struct derived_rec_char *)gen_list_remove( lchar, gen_list_get_last( lchar ) ) );
	derived_rec_char_destruct( (struct derived_rec_char *)gen_list_remove( lchar, gen_list_get_last( lchar ) ) );
	derived_rec_char_destruct( (struct derived_rec_char *)gen_list_remove( lchar, gen_list_get_last( lchar ) ) );


	printf( "** -- Calling gen_list_destruct to destruct the original charptr list (less the middle record) -- **\n" );
	lcharptr = gen_list_destruct( lcharptr );
	printf( "** -- Calling gen_list_destruct to destruct the copied charptr list (less the first record) -- **\n" );
	lcharptr_c = gen_list_destruct( lcharptr_c );

	printf( "** -- Calling gen_list_destruct to destruct the original long list -- **\n" );
	llong = gen_list_destruct( llong );
	printf( "** -- Calling gen_list_destruct to destruct the copied long list (less the last record) -- **\n" );
	llong_c = gen_list_destruct( llong_c );

	printf( "** -- Calling gen_list_destruct to destruct the original double list -- **\n" );
	ldouble = gen_list_destruct( ldouble );
	printf( "** -- Calling gen_list_destruct to destruct the copied double list -- **\n" );
	ldouble_c = gen_list_destruct( ldouble_c );

	printf( "** -- Calling gen_list_destruct to destruct the original char list (less all records last to first) -- **\n" );
	lchar = gen_list_destruct( lchar );
	printf( "** -- Calling gen_list_destruct to destruct the copied char list (less all records first to last) -- **\n" );
	lchar_c = gen_list_destruct( lchar_c );


	/* Force another memory leak to test the strdup/malloc/free police. */
	/* NOTE: this should trigger the alphanum check of allocated memory. */
	STRDUP( "Force another memory leak to test the strdup/malloc/free police." );

	/* Force a memory leak in a list and also in 2 nodes. */
	/* NOTE: this should NOT trigger the alphanum check of allocated memory. */
	gen_list_construct();

	/* NOTE: this should trigger 1 NON check (for the node)	*/
	/* followed by 1 alphanum check for the charptr string.	*/
	derived_rec_charptr_construct( "Leaky charptr node." );

	/* NOTE: this should NOT trigger the alphanum check of allocated memory. */
	derived_rec_char_construct( 'Z' );


	printf( "\ndone" );
	return( 0 );

}


/*
  Local Variables:
  tab-width: 3
  end:
*/
