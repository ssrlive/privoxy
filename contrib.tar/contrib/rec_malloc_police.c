const char rec_malloc_police_rcs[] = "$Id: rec_malloc_police.c,v 1.1 2001/10/25 03:40:48 rodney.stromlund Exp $";
/*********************************************************************
 *
 * File        :  $Source: /cvsroot/ijbswa/current/gen_list.c,v $
 *
 * Purpose     :  A "derived class" of gen_list_rec.
 *						This class helps to build a list of allocated and
 *						freed memory.  When the program exits, we will print
 *						a list of all memory that was allocated, but never
 *						freed.  This could be most helpful to developers
 *						and debugers.
 *
 * Copyright   :  Written by and Copyright (C) 2001 the SourceForge
 *                IJBSWA team.  http://ijbswa.sourceforge.net
 *
 *                This program is free software; you can redistribute it
 *                and/or modify it under the terms of the GNU General
 *                Public License as published by the Free Software
 *                Foundation; either version 2 of the License, or (at
 *                your option) any later version.
 *
 *                This program is distributed in the hope that it will
 *                be useful, but WITHOUT ANY WARRANTY; without even the
 *                implied warranty of MERCHANTABILITY or FITNESS FOR A
 *                PARTICULAR PURPOSE.  See the GNU General Public
 *                License for more details.
 *
 *                The GNU General Public License should be included with
 *                this file.  If not, you can view it at
 *                http://www.gnu.org/copyleft/gpl.html
 *                or write to the Free Software Foundation, Inc., 59
 *                Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * VI users		:	Please "set tabstop=3 shiftwidth=3" to view this file,
 *						and edit IJB, correctly.
 *
 * Revisions   :
 *    $Log: rec_malloc_police.c,v $
 *
 *********************************************************************/


#include <stdio.h>

#include "gen_list.h"
#include "malloc_police.h"
#include "rec_malloc_police.h"

const char rec_malloc_police_h_rcs[] = REC_MALLOC_POLICE_H_VERSION;


static const rec_method rec_malloc_police_vtable[] =
{
	(rec_method)derived_rec_malloc_police_copy_construct,
	(rec_method)derived_rec_malloc_police_destruct,
	(rec_method)derived_rec_malloc_police_stream,
	(rec_method)derived_rec_malloc_police_equal
};


/*********************************************************************
 *
 * Function    :  derived_rec_malloc_police_construct
 *
 * Description :  A simple derived record class that contains 1 string.
 *
 * Parameters  :
 *          1  :  The record
 *          2  :  The string to contain.
 *
 * Returns     :  A pointer to the constructed record.
 *
 *********************************************************************/
struct derived_rec_malloc_police *derived_rec_malloc_police_construct( void *_alloced_addr, char *_source_where, size_t _sz )
{
	struct derived_rec_malloc_police *this_rec;
	list_is_quiet ++;

	this_rec = (struct derived_rec_malloc_police *)gen_list_rec_construct(
		ISA_MALLOC_POLICE,
		sizeof( struct derived_rec_malloc_police ),
		rec_malloc_police_vtable
	);

	this_rec->alloced_addr	= _alloced_addr;
	this_rec->source_where	= STRDUP( _source_where );
	this_rec->sz				= _sz;

/* 	LIST_SHOW( printf( "\ */
/* \t\tmalloc_police construct new rec\t\t\t\t\t= %p */
/* \t\tmalloc_police construct new rec alloced_addr = %p */
/* \t\tmalloc_police construct new rec source_where = %s */
/* \t\tmalloc_police construct new rec sz\t\t\t\t\t= %ld\n\n", */
/* 			  (const void *)this_rec, */
/* 			  this_rec->alloced_addr, */
/* 			  this_rec->source_where, */
/* 			  this_rec->sz */
/* 	) ); */

	list_is_quiet --;

	return( this_rec );

}


/*********************************************************************
 *
 * Function    :  derived_rec_malloc_police_copy_construct
 *
 * Description :  Copies one malloc_police record to another.
 *
 * Parameters  :
 *          1  :  Existing record.
 *				2	:  Copy record.
 *
 * Returns     :  The newly constructed copy record.
 *
 *********************************************************************/
struct derived_rec_malloc_police *derived_rec_malloc_police_copy_construct( const struct derived_rec_malloc_police *this_rec )
{
	int len;
	char *new_contents;
	struct derived_rec_malloc_police *copy_rec;

	list_is_quiet ++;

	copy_rec = (struct derived_rec_malloc_police *)gen_list_rec_copy_construct( (struct gen_list_rec *)this_rec );

	copy_rec->alloced_addr	= this_rec->alloced_addr;
	copy_rec->source_where	= STRDUP( this_rec->source_where );
	copy_rec->sz				= this_rec->sz;

/* 	LIST_SHOW( printf( "\ */
/* \t\tmalloc_police copy construct new gen rec = %p => %p */
/* \t\tmalloc_police copy construct new gen rec alloced_addr = %p */
/* \t\tmalloc_police copy construct new gen rec source_where = %s */
/* \t\tmalloc_police copy construct new gen rec sz\t\t\t\t\t= %ld\n\n", */
/* 			  (const void *)this_rec, (const void *)copy_rec, */
/* 			  copy_rec->alloced_addr, */
/* 			  copy_rec->source_where, */
/* 			  copy_rec->sz */
/* 	) ); */

	list_is_quiet --;

	return( copy_rec );

}


/*********************************************************************
 *
 * Function    :  derived_rec_malloc_police_destruct	
 *
 * Description :  Destruct the malloc_police record.
 *
 * Parameters  :
 *          1  :  The record.
 *
 * Returns     :  NULL
 *
 *********************************************************************/
struct derived_rec_malloc_police *derived_rec_malloc_police_destruct( struct derived_rec_malloc_police *this_rec )
{
	struct derived_rec_malloc_police *d;
	list_is_quiet ++;

/* 	LIST_SHOW( printf( "\ */
/* \t\tmalloc_police destruct this_rec\t\t\t\t\t\t= %p */
/* \t\tmalloc_police destruct this_rec->alloced_addr\t= %p */
/* \t\tmalloc_police destruct this_rec->source_where\t= %s, */
/* \t\tmalloc_police destruct this_rec->sz\t\t\t\t\t= %ld\n\n", */
/* 			  (const void *)this_rec, */
/* 			  this_rec->alloced_addr, */
/* 			  this_rec->source_where, */
/* 			  this_rec->sz */
/* 	) ); */

	memset( this_rec->source_where, '!', strlen( this_rec->source_where ) );
	FREE( this_rec->source_where );

	d = (struct derived_rec_malloc_police *)gen_list_rec_destruct( (struct gen_list_rec *)this_rec );
	list_is_quiet --;

	return( d );

}


/*********************************************************************
 *
 * Function    :  derived_rec_malloc_police_stream
 *
 * Description :  Displays all malloc_police attributes on the STDOUT stream.
 *
 * Parameters  :
 *          1  :  The record.
 *
 * Returns     :  The record.
 *
 *********************************************************************/
const struct derived_rec_malloc_police *derived_rec_malloc_police_stream( const struct derived_rec_malloc_police *this_rec )
{
	list_is_quiet ++;

	this_rec = (struct derived_rec_malloc_police *)gen_list_rec_stream(
		(struct gen_list_rec *)this_rec
	);
	LIST_SHOW( printf( "\
\t\tmalloc_police stream this_rec\t\t\t\t\t= %p
\t\tmalloc_police stream this_rec->alloced_addr\t= %p
\t\tmalloc_police stream this_rec->source_where\t= %s
\t\tmalloc_police stream this_rec->sz\t\t\t\t= %ld\n\n",
							 (const void *)this_rec,
							 this_rec->alloced_addr,
							 this_rec->source_where,
							 this_rec->sz
	) );

	list_is_quiet --;
	return( this_rec );

}


/*********************************************************************
 *
 * Function    :  derived_rec_malloc_police_equal
 *
 * Description :  Compares two malloc_police records to see if they are equal.
 *
 * Parameters  :
 *          1  :  A record.
 *          2  :  Another record.
 *
 * Returns     :  0 => NOT EQUAL, anything else is EQUAL.
 *
 *********************************************************************/
int derived_rec_malloc_police_equal( const struct derived_rec_malloc_police *this_rec, const struct derived_rec_malloc_police *eq_rec )
{
	list_is_quiet ++;

	if ( ! gen_list_rec_equal( (const struct gen_list_rec *)this_rec, (struct gen_list_rec *)eq_rec ) )
	{
		return( 0 );
	}

	list_is_quiet --;
	return( this_rec->alloced_addr == eq_rec->alloced_addr );

}
