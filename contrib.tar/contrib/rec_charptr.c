const char rec_charptr_rcs[] = "$Id: rec_charptr.c,v 1.1 2001/10/25 03:40:48 rodney.stromlund Exp $";
/*********************************************************************
 *
 * File        :  $Source: /cvsroot/ijbswa/current/gen_list.c,v $
 *
 * Purpose     :  A "derived class" of gen_list_rec.
 *
 * Copyright   :  Written by and Copyright (C) 2001 the SourceForge
 *                IJBSWA team.  http://ijbswa.sourceforge.net
 *
 *                This program is free software; you can redistribute it
 *                and/or modify it under the terms of the GNU General
 *                Public License as published by the Free Software
 *                Foundation; either version 2 of the License, or (at
 *                your option) any later version.
 *
 *                This program is distributed in the hope that it will
 *                be useful, but WITHOUT ANY WARRANTY; without even the
 *                implied warranty of MERCHANTABILITY or FITNESS FOR A
 *                PARTICULAR PURPOSE.  See the GNU General Public
 *                License for more details.
 *
 *                The GNU General Public License should be included with
 *                this file.  If not, you can view it at
 *                http://www.gnu.org/copyleft/gpl.html
 *                or write to the Free Software Foundation, Inc., 59
 *                Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * VI users		:	Please "set tabstop=3 shiftwidth=3" to view this file,
 *						and edit IJB, correctly.
 *
 * Revisions   :
 *    $Log: rec_charptr.c,v $
 *
 *********************************************************************/


#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gen_list.h"
#include "rec_charptr.h"
#include "malloc_police.h"

const char rec_charptr_h_rcs[] = REC_CHARPTR_H_VERSION;


static const rec_method rec_charptr_vtable[] =
{
	(rec_method)derived_rec_charptr_copy_construct,
	(rec_method)derived_rec_charptr_destruct,
	(rec_method)derived_rec_charptr_stream,
	(rec_method)derived_rec_charptr_equal
};


/*********************************************************************
 *
 * Function    :  derived_rec_charptr_construct
 *
 * Description :  A simple derived record class that contains 1 string.
 *
 * Parameters  :
 *          1  :  The record
 *          2  :  The string to contain.
 *
 * Returns     :  A pointer to the constructed record.
 *
 *********************************************************************/
struct derived_rec_charptr *derived_rec_charptr_construct( const char *_contents )
{
	struct derived_rec_charptr *this_rec = (struct derived_rec_charptr *)gen_list_rec_construct(
		ISA_CHARPTR,
		sizeof( struct derived_rec_charptr ),
		rec_charptr_vtable
	);

	this_rec->contents = STRDUP( _contents );

	LIST_SHOW( printf( "\
\t\tcharptr construct new rec\t\t\t\t= %p
\t\tcharptr construct new rec contents\t= %s\n\n", (const void *)this_rec, this_rec->contents ) );

	return( this_rec );

}


/*********************************************************************
 *
 * Function    :  derived_rec_charptr_copy_construct
 *
 * Description :  Copies one charptr record to another.
 *
 * Parameters  :
 *          1  :  Existing record.
 *				2	:  Copy record.
 *
 * Returns     :  The newly constructed copy record.
 *
 *********************************************************************/
struct derived_rec_charptr *derived_rec_charptr_copy_construct( const struct derived_rec_charptr *this_rec )
{
	int len;
	char *new_contents;

	struct derived_rec_charptr *copy_rec = (struct derived_rec_charptr *)gen_list_rec_copy_construct( (struct gen_list_rec *)this_rec );

	len = strlen( this_rec->contents );
	len += sizeof( "COPY " );

	copy_rec->contents = (char *)MALLOC( len );
	strcpy( copy_rec->contents, "COPY " );
	strcat( copy_rec->contents, this_rec->contents );

	LIST_SHOW( printf( "\
\t\tcharptr copy construct new gen rec\t\t\t\t= %p => %p
\t\tcharptr copy construct new gen rec contents\t= %s\n\n", (const void *)this_rec, (const void *)copy_rec, copy_rec->contents ) );


	return( copy_rec );

}


/*********************************************************************
 *
 * Function    :  derived_rec_charptr_destruct	
 *
 * Description :  Destruct the charptr record.
 *
 * Parameters  :
 *          1  :  The record.
 *
 * Returns     :  NULL
 *
 *********************************************************************/
struct derived_rec_charptr *derived_rec_charptr_destruct( struct derived_rec_charptr *this_rec )
{
	LIST_SHOW( printf( "\
\t\tcharptr destruct this_rec\t\t\t\t= %p
\t\tcharptr destruct this_rec->contents\t= %s\n\n", (const void *)this_rec, (const void *)this_rec->contents ) );

	memset( this_rec->contents, '!', strlen( this_rec->contents ) );
	FREE( this_rec->contents );
	return( (struct derived_rec_charptr *)gen_list_rec_destruct( (struct gen_list_rec *)this_rec ) );

}


/*********************************************************************
 *
 * Function    :  derived_rec_charptr_stream
 *
 * Description :  Displays all charptr attributes on the STDOUT stream.
 *
 * Parameters  :
 *          1  :  The record.
 *
 * Returns     :  The record.
 *
 *********************************************************************/
const struct derived_rec_charptr *derived_rec_charptr_stream( const struct derived_rec_charptr *this_rec )
{
	this_rec = (struct derived_rec_charptr *)gen_list_rec_stream(
		(struct gen_list_rec *)this_rec
	);
	LIST_SHOW( printf( "\
\t\tcharptr stream this_rec\t\t\t\t\t= %p
\t\tcharptr stream this_rec->contents\t= %s\n\n", (const void *)this_rec, this_rec->contents ) );

	return( this_rec );

}


/*********************************************************************
 *
 * Function    :  derived_rec_charptr_equal
 *
 * Description :  Compares two charptr records to see if they are equal.
 *
 * Parameters  :
 *          1  :  A record.
 *          2  :  Another record.
 *
 * Returns     :  0 => NOT EQUAL, anything else is EQUAL.
 *
 *********************************************************************/
int derived_rec_charptr_equal( const struct derived_rec_charptr *this_rec, const struct derived_rec_charptr *eq_rec )
{
	if ( ! gen_list_rec_equal( (const struct gen_list_rec *)this_rec, (struct gen_list_rec *)eq_rec ) )
	{
		return( 0 );
	}
	return( 0 == strcmp( this_rec->contents, eq_rec->contents ) );

}
