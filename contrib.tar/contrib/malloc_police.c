const char malloc_police_rcs[] = "$Id: malloc_police.c,v 1.1 2001/10/25 03:40:48 rodney.stromlund Exp $";
/*********************************************************************
 *
 * File        :  $Source: /cvsroot/ijbswa/current/gen_list.c,v $
 *
 * Purpose     :  This module uses the rec_malloc_police to build a
 *						list of allocated and freed memory.  When the
 *						program exits, we will print a list of all memory
 *						that was allocated, but never freed.  This could
 *						be most helpful to developers and debugers.
 *
 * Copyright   :  Written by and Copyright (C) 2001 the SourceForge
 *                IJBSWA team.  http://ijbswa.sourceforge.net
 *
 *                This program is free software; you can redistribute it
 *                and/or modify it under the terms of the GNU General
 *                Public License as published by the Free Software
 *                Foundation; either version 2 of the License, or (at
 *                your option) any later version.
 *
 *                This program is distributed in the hope that it will
 *                be useful, but WITHOUT ANY WARRANTY; without even the
 *                implied warranty of MERCHANTABILITY or FITNESS FOR A
 *                PARTICULAR PURPOSE.  See the GNU General Public
 *                License for more details.
 *
 *                The GNU General Public License should be included with
 *                this file.  If not, you can view it at
 *                http://www.gnu.org/copyleft/gpl.html
 *                or write to the Free Software Foundation, Inc., 59
 *                Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * VI users		:	Please "set tabstop=3 shiftwidth=3" to view this file,
 *						and edit IJB, correctly.
 *
 * Revisions   :
 *    $Log: malloc_police.c,v $
 *
 *********************************************************************/


#include <ctype.h>
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gen_list.h"
#include "malloc_police.h"
#include "rec_malloc_police.h"

const char malloc_police_h_rcs[] = MALLOC_POLICE_H_VERSION;


/* When we need to allocate malloc_police records, we */
/* will do recursion infinately.  This variable will */
/* stop the STRDUP, MALLOC, and FREE replacements from */
/* trying to log these allocations. */

char recursion_protect = 0;

struct gen_list *get_police_list();
static char called_once = 0;
static const char *leak_report_header = "%s****************************** MEMORY LEAK REPORT %s ******************************%s";


/*********************************************************************
 *
 * Function    :  police_list_release_iterator
 *
 * Description :  Iterator for the police list.  We will report
 *						"leaked" memory for the developer to correct.
 *
 * Parameters  :
 *          1  :  The record.
 *
 * Returns     :  NULL
 *
 *********************************************************************/
struct derived_rec_malloc_police *police_list_release_iterator( struct derived_rec_malloc_police *this_rec )
{
	if ( ! called_once )
	{
		called_once = 1;
		fprintf( stderr, leak_report_header, "\n\n", "BEGIN", "\n\n" );
	}

	fprintf( stderr, "\
\t\tmalloc_police leaked memory iterator this_rec\t\t\t\t\t= %p
\t\tmalloc_police leaked memory iterator this_rec->alloced_addr\t= %p
\t\tmalloc_police leaked memory iterator this_rec->source_where\t= %s
\t\tmalloc_police leaked memory iterator this_rec->sz\t\t\t\t= %ld\n",
				(const void *)this_rec,
				this_rec->alloced_addr,
				this_rec->source_where,
				this_rec->sz
	);

	if (
		this_rec->sz >= 3 &&
		isalnum( ((const char *)this_rec->alloced_addr)[ 0 ] ) &&
		isalnum( ((const char *)this_rec->alloced_addr)[ 1 ] ) &&
		isalnum( ((const char *)this_rec->alloced_addr)[ 2 ] ) )
	{
		/* If the memory starts with 3 alpha-numerics,
		 * assume a string was allocated.  This might be
		 * a little dangerous for production code, but I
		 * will take the risk for development payoff
		 * (at least for now ...) */
			
		fprintf( stderr, "\
\t\tAlpha numeric found, assuming a string was allocated\t\t\t= %s\n",
					this_rec->alloced_addr
		);
	}

	fprintf( stderr, "\n" );

	return( NULL );

}


/*********************************************************************
 *
 * Function    :  release_police_list
 *
 * Description :  Iterates the police_list and reports "leaked" memory.
 *						It will then free the list itself.
 *
 * Parameters  :	None
 *
 * Returns     :  None.
 *
 *********************************************************************/
void release_police_list()
{
	struct gen_list *police_list = get_police_list();
	fflush( stdout );
	gen_list_iterate( police_list, (rec_iterate)police_list_release_iterator );

	if ( called_once )
	{
		called_once = 0;
		fprintf( stderr, leak_report_header, "", "END", "\n" );
	}

}


/*********************************************************************
 *
 * Function    :  get_police_list
 *
 * Description :  Get the police malloc/strdup/free list.  Generate
 *						a new one if it does not yet exist.
 *
 * Parameters  :	None
 *
 * Returns     :  The police list.
 *
 *********************************************************************/
struct gen_list *get_police_list()
{
	static struct gen_list *police_list = NULL;

	if ( NULL == police_list )
	{
		recursion_protect ++;
		list_is_quiet ++;

		police_list = gen_list_construct();
		atexit( release_police_list );

		recursion_protect --;
		list_is_quiet --;
	}

	return( police_list );

}


/*********************************************************************
 *
 * Function    :  police_strdup
 *
 * Description :  Save the results of the strdup into our linked list.
 *						This will be checked against latter free(s).
 *
 * Parameters  :
 *          1  :  The string to be duplicated.
 *          2  :  Filename where the strdup occured.
 *          3  :  Line# of where the strdup occured.
 *
 * Returns     :  Pointer to newly allocated memory.
 *
 * NOTE			:	This could replace the custom strdup for __MINGW32__
 *						systems.  We only need to copy the conditionally
 *						compiled code here and eliminate the strdup copy.
 *
 *********************************************************************/
char *police_strdup( const char *s, const char *filename, long lineno )
{
	char *ret = strdup( s );

	if ( 0 == recursion_protect )
	{
		char buffer[ 255 ];
		sprintf( buffer, "strdup : %s @ %ld for %ld (%s)", filename, lineno, strlen( s ) + 1, s );

		recursion_protect ++;
		list_is_quiet ++;

		gen_list_insert(
			get_police_list(),
			(struct gen_list_rec *)derived_rec_malloc_police_construct( ret, buffer, strlen( s ) + 1 )
		);

		recursion_protect --;
		list_is_quiet --;
	}

	return( ret );

}


/*********************************************************************
 *
 * Function    :  police_malloc
 *
 * Description :  Save the results of the malloc into our linked list.
 *						This will be checked against latter free(s).
 *
 * Parameters  :
 *          1  :  The size of the memory to be malloc(ed).
 *          2  :  Filename where the malloc occured.
 *          3  :  Line# of where the malloc occured.
 *
 * Returns     :  0 => NOT EQUAL, anything else is EQUAL.
 *
 *********************************************************************/
void *police_malloc( size_t sz, const char *filename, long lineno )
{
	void *ret = malloc( sz );

	if ( 0 == recursion_protect )
	{
		char buffer[ 255 ];
		sprintf( buffer, "malloc : %s @ %ld for %ld", filename, lineno, sz );

		recursion_protect ++;
		list_is_quiet ++;

		gen_list_insert(
			get_police_list(),
			(struct gen_list_rec *)derived_rec_malloc_police_construct( ret, buffer, sz )
		);

		recursion_protect --;
		list_is_quiet --;
	}

	return( ret );

}


/*********************************************************************
 *
 * Function    :  police_free
 *
 * Description :  Frees the memory allocation and removes the address
 *						from the linked list.  Anything left in this list
 *						is "leaked" memory.
 *
 * Parameters  :
 *          1  :  Pointer to the memory to be freed.
 *          2  :  Filename where the free occured.
 *          3  :  Line# of where the free occured.
 *
 * Returns     :  0 => NOT EQUAL, anything else is EQUAL.
 *
 *********************************************************************/
void police_free( void *ptr, const char *filename, long lineno )
{
	if ( 0 == recursion_protect )
	{
		struct derived_rec_malloc_police *rec;
		struct gen_list_rec *fRec;
		struct gen_list *l = get_police_list();

		recursion_protect ++;
		list_is_quiet ++;

		rec = derived_rec_malloc_police_construct( ptr, "FREEING POLICE RECORD.", 23 );
		fRec = gen_list_find( l, (struct gen_list_rec *)rec );
		derived_rec_malloc_police_destruct( rec );

		if ( NULL == fRec )
		{
			fprintf( stderr, "\nERROR: free failed to find corresponding strdup/malloc : %s @ %ld\n", filename, lineno );
		}
		else
		{
			derived_rec_malloc_police_destruct( (struct derived_rec_malloc_police *)gen_list_remove( l, fRec ) );
		}

		recursion_protect --;
		list_is_quiet --;
	}

	free( ptr );

}
