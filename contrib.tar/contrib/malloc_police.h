#ifndef MALLOC_POLICE_H_INCLUDED
#define MALLOC_POLICE_H_INCLUDED
#define MALLOC_POLICE_H_VERSION "$Id: malloc_police.h,v 1.1 2001/07/29 18:50:04 rodney.stromlund Exp $"
/*********************************************************************
 *
 * File        :  $Source: /cvsroot/ijbswa/current/rec_char.h,v $
 *
 * Purpose     :  This module uses the rec_malloc_police to build a
 *						list of allocated and freed memory.  When the
 *						program exits, we will print a list of all memory
 *						that was allocated, but never freed.  This could
 *						be most helpful to developers and debugers.
 *
 * Copyright   :  Written by and Copyright (C) 2001 the SourceForge
 *                IJBSWA team.  http://ijbswa.sourceforge.net
 *
 *                This program is free software; you can redistribute it
 *                and/or modify it under the terms of the GNU General
 *                Public License as published by the Free Software
 *                Foundation; either version 2 of the License, or (at
 *                your option) any later version.
 *
 *                This program is distributed in the hope that it will
 *                be useful, but WITHOUT ANY WARRANTY; without even the
 *                implied warranty of MERCHANTABILITY or FITNESS FOR A
 *                PARTICULAR PURPOSE.  See the GNU General Public
 *                License for more details.
 *
 *                The GNU General Public License should be included with
 *                this file.  If not, you can view it at
 *                http://www.gnu.org/copyleft/gpl.html
 *                or write to the Free Software Foundation, Inc., 59
 *                Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * VI users		:	Please "set tabstop=3 shiftwidth=3" to view this file,
 *						and edit IJB, correctly.
 *
 * Revisions   :
 *    $Log: malloc_police.h,v $
 *
 *********************************************************************/


#ifdef __cplusplus
extern "C" {
#endif


char *police_strdup( const char *s, const char *filename, long lineno );
void *police_malloc( size_t sz, const char *filename, long lineno );
void police_free( void *ptr, const char *filename, long lineno );

#define STRDUP(s)			police_strdup( s, __FILE__, __LINE__ )
#define MALLOC(sz)		police_malloc( sz, __FILE__, __LINE__ )
#define FREE(ptr)			police_free( ptr, __FILE__, __LINE__ )


#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* ndef MALLOC_POLICE_H_INCLUDED */

/*
  Local Variables:
  tab-width: 3
  end:
*/
